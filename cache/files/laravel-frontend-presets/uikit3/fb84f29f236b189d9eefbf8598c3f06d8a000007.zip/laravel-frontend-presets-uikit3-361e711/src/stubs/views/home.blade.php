@extends('layouts.app')

@section('content')

<div class="uk-section">
    <div class="uk-container uk-container-expand">

        <div class="uk-card uk-card-primary uk-card-body uk-width-1-2@m uk-align-center">
            <h3 class="uk-card-title">Dashboard</h3>
            <p>You are logged in!</p>
        </div>

    </div>
</div>

@endsection
