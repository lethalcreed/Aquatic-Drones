<?php

namespace Illuminate\Foundation\Testing;

use PHPUnit\Framework\ExpectationFailedException;

class HttpException extends ExpectationFailedException
{
    //
}
